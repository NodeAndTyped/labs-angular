import { UsersOnlinePipe } from './users-online.pipe';

describe('UsersOnlinePipe', () => {
  it('create an instance', () => {
    const pipe = new UsersOnlinePipe();
    expect(pipe).toBeTruthy();
  });
});
