import { DecToStrPipe } from './dec-to-str.pipe';

describe('DecToStrPipe', () => {
  it('create an instance', () => {
    const pipe = new DecToStrPipe();
    expect(pipe).toBeTruthy();
  });
});
