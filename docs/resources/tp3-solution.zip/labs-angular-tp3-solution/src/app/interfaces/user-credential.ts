export class UserCredential {
    email: string;
    password: string;
}